<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kriteria_model extends CI_Model
{
  public function addKriteria()
  {
    $data = [
      'nama_kriteria' => $this->input->post('nama_kriteria', true),
      'attribut' => $this->input->post('attribut', true),
      'bobot_kriteria' => $this->input->post('bobot', true)
    ];

    //querynya
    $this->db->insert('kriteria', $data);
  }
  public function editKriteria()
  {
    $data = [
      'nama_kriteria' => $this->input->post('nama'),
      'attribut' => $this->input->post('attribut'),
      'bobot_kriteria' => $this->input->post('bobot')
    ];

    $this->db->where('id_kriteria', $this->input->post('id_kriteria'));
    $this->db->update('kriteria', $data);
  }

  public function deleteKriteria($id)
  {
    $this->db->where('id_kriteria', $id);
    $this->db->delete('kriteria');
  }
}
