<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Member extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('Member_model', 'member');
  }
  public function addMember()
  {

    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

    //cek jika ada gambar yang di akan diupload
    $gambar = $_FILES['image']['name'];
    if ($gambar = '') {
      # code...
    } else {
      $config['upload_path']          = './asset/images/';
      $config['allowed_types']        = 'gif|jpg|png|jpeg';
      $config['max_size']             = 2048;
      $config['max_width']            = 8000;
      $config['max_height']           = 9000;
      $this->load->library('upload', $config);
      if (!$this->upload->do_upload('image')) {
        echo "Gagal";
      } else {
        $this->member->addMember();
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Member berhasil ditambahkan!</div>');
        redirect('admin/member');
      }
    }
    $this->member->addMember($data);
    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
        Data Member Berhasil Ditambhakan!
        </div>');
    redirect('admin/member');
  }

  public function editMember()
  {
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    // cek jika ada gambar yang akan diupload
    $upload_image = $_FILES['image']['name'];
    if ($upload_image) {
      $config['upload_path']          = './asset/images/';
      $config['allowed_types']        = 'gif|jpg|png|jpeg';
      $config['max_size']             = 2048;
      $config['max_width']            = 8000;
      $config['max_height']           = 9000;

      $this->load->library('upload', $config);

      if ($this->upload->do_upload('image')) {
        $old_image = $data['user']['image'];
        if ($old_image != 'user.png') {
          unlink(FCPATH . 'asset/images/' . $old_image);
        }
        $new_image = $this->upload->data('file_name');

        //insert image ke tbl user pada kolom image
        $this->db->set('image', $new_image);
      } else {
        echo $this->upload->dispay_errors();
      }
    }
    $this->member->editMember();
    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Member berhasil diubah!</div>');
    redirect('admin/member');
  }

  public function deleteMember($id)
  {
    $this->member->deleteMember($id);
    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Pengguna berhasil dihapus!</div>');
    redirect('admin/member');
  }
}
