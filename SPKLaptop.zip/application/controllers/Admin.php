<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    sudah_login();
    $this->load->model('Admin_model', 'admin');
    $this->load->library('form_validation');
    $this->load->model('Laptop_model', 'laptop');
  }
  public function index()
  {
    $data['judul'] = "Admin DSS";
    $data['user'] = $this->admin->getUser();

    $this->load->view('Templates/admin_header', $data);
    $this->load->view('Templates/admin_sidebar', $data);
    $this->load->view('Templates/admin_topbar', $data);
    $this->load->view('Admin/index', $data);
    $this->load->view('Templates/admin_footer');
  }
  public function member()
  {
    $data['judul'] = 'User DSS';
    $data['nama_tbl'] = 'Tabel User';
    $data['user'] = $this->admin->getUser();

    $data['member'] = $this->admin->getMember();
    $data['role'] = $this->admin->getRole();

    $this->load->view('Templates/admin_header', $data);
    $this->load->view('Templates/admin_sidebar', $data);
    $this->load->view('Templates/admin_topbar', $data);
    $this->load->view('Admin/member', $data);
    $this->load->view('Templates/admin_footer');
    $this->load->view('Admin/modal/add/modal_add_member');
    $this->load->view('Admin/modal/edit/modal_edit_member', $data);
  }
  public function kriteria()
  {
    $data['judul'] = 'Kriteria DSS';
    $data['nama_tbl'] = 'Tabel Kriteria';
    $data['kriteria'] = $this->admin->getKriteria();
    $data['user'] = $this->admin->getUser();
    $data['role'] = $this->admin->getRole();

    $this->load->view('Templates/admin_header', $data);
    $this->load->view('Templates/admin_sidebar', $data);
    $this->load->view('Templates/admin_topbar', $data);
    $this->load->view('Admin/kriteria', $data);
    $this->load->view('Templates/admin_footer');
    $this->load->view('Admin/modal/add/modal_add_kriteria');
    $this->load->view('Admin/modal/edit/modal_edit_kriteria', $data);
  }
  public function laptop()
  {
    $data['judul'] = 'Data Laptop DSS';
    $data['nama_tbl'] = 'Tabel Data Laptop';
    $data['kategoriDesign'] = 'Tabel Laptop Kategori Design';
    $data['kategoriOffice'] = 'Tabel Laptop Kategori Office';
    $data['design'] = $this->admin->getLaptopDesign();
    $data['office'] = $this->admin->getLaptopOffice();
    $data['user'] = $this->admin->getUser();
    $data['role'] = $this->admin->getRole();
    $data['laptop'] = $this->admin->getLaptop();
    $data['kebutuhan'] = $this->admin->getKebutuhan();

    $this->load->view('Templates/admin_header', $data);
    $this->load->view('Templates/admin_sidebar', $data);
    $this->load->view('Templates/admin_topbar', $data);
    $this->load->view('Admin/laptop', $data);
    $this->load->view('Templates/admin_footer');
    $this->load->view('Admin/modal/add/modal_add_laptop');
    $this->load->view('Admin/modal/edit/modal_edit_laptop', $data);
  }
  public function perhitungan()
  {
    $data['judul'] = 'Perhitungan DSS';
    $data['nama_tbl'] = 'Perhitungan Laptop';
    $data['user'] = $this->admin->getUser();
    $data['role'] = $this->admin->getRole();

    $this->load->view('Templates/admin_header', $data);
    $this->load->view('Templates/admin_sidebar', $data);
    $this->load->view('Templates/admin_topbar', $data);
    $this->load->view('Admin/laptop', $data);
    $this->load->view('Templates/admin_footer');
    $this->load->view('Admin/modal/add/modal_add_laptop');
    $this->load->view('Admin/modal/edit/modal_edit_laptop', $data);
  }
}
